<?php
 class Coupon {

    //properties 
    public $name;
    public $event;
    public $discountPercent;

    function __construct($name,$event,$discountPercent){
       $this->name = $name;
       $this->event = $event;
       $this->discountPercent = $discountPercent;
    }

   function  set_name($name){
       $this->name = $name;
   }
   function get_name(){
       return $this->name;
   }
}

$C1 = new Coupon("Christmas","ChritmasPromo",015);
echo $C1->name;

?>

<html>
    <head>
    </head>
    <body>
        <form action="coupon2.class.php" method ="post">
        <input type="text" name="name" placeholder="Enter CouponName">
        <input type="text" name="event" placeholder="Enter CouponEvent">
        <input type="text" name="discountPercent" placeholder="Enter CouponDiscountPercent">
        <input type="submit">
        </form>
    </body>
</html>

