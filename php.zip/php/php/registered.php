<html>
<head> 
	<title>Welcome to Registration Page </title>
	<script src="BasicFunction.js">  </script>

</head>
<body>
<br><br>

<center> <b><font size = "6" color ="blue">Welcome to Registration Page</font></b></center>
<hr size ="2"color = "orange"/>

<div>
	<?php
    echo "Your are now Registered";
	echo "<br>";
	
	$e1 = $_POST['empid'];
	$e2 = $_POST['ename'];
	$e3 = $_POST['ecity'];
	$e4 = $_POST['ephone'];
	$e5 = $_POST['x'];
	$e6 = $_POST['epassword'];
	$e7 = $_POST['edate'];
	$e8 = $_POST['efile'];

	if (isset($_POST["submit"])) {
	
	$con = mysqli_connect("localhost", "root", "", "user");
	$query = "insert into user values ('$e1','$e2','$e3','$e4','$e5','$e6','$e7','$e8')";
	$result = mysqli_query($con, $query);
	if ($result){
	}
	else {
		echo "fail";
	}
	}
    ?>
</div>
</body>
</html>





