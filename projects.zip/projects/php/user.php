<?php 

 class user{

   function getName(){
       
   }
}
?>